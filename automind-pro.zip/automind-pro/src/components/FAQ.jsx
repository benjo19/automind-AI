import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  const faqs = [
    {
      question: 'Koliko brzo možemo krenuti?',
      answer: 'Većina klijenata je operativna u roku od 24 sata. Trebate samo Google Sheets s postavkama i predlošcima, a mi se brinjemo za ostatak.',
    },
    {
      question: 'Je li moguć white-label?',
      answer: 'Apsolutno! Možete koristiti vlastiti branding, logotip i domenu. Vaši klijenti će vidjeti samo vašu marku.',
    },
    {
      question: 'Podržavate li hrvatski voice?',
      answer: 'Da, voice bot ima prirodan hrvatski glas s mogućnošću prilagodbe brzine i tona. Klijenti često ne znaju da je to AI.',
    },
    {
      question: 'Kako funkcionira model naplate?',
      answer: 'Naplaćujemo po broju aktivnih agenata i razgovora. Nema skrivenih troškova. Možete početi s malim brojem agenata i skalirati prema potrebi.',
    },
    {
      question: 'Mogu li integrirati s postojećim sustavima?',
      answer: 'Podržavamo integracije s većinom popularne platforme - CRM, email, Slack, WhatsApp, Telegram i više od 1000 aplikacija kroz Make.com.',
    },
    {
      question: 'Što ako trebam podršku?',
      answer: 'Dostupni smo 24/7 putem chata, emaila i telefona. Svaki klijent ima dodijeljen account manager koji vam pomaže s optimizacijom.',
    },
  ];

  return (
    <section id="faq" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Često postavljana pitanja
          </h2>
          <p className="text-xl text-slate-400">
            Odgovori na sve što vas zanima o Automind Pro
          </p>
        </motion.div>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              viewport={{ once: true }}
              className="glass rounded-xl border border-slate-700/50 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === idx ? -1 : idx)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-slate-800/30 transition-colors duration-300"
              >
                <h3 className="text-lg font-semibold text-white text-left">{faq.question}</h3>
                <motion.div
                  animate={{ rotate: openIndex === idx ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex-shrink-0 ml-4"
                >
                  <ChevronDown size={20} className="text-indigo-400" />
                </motion.div>
              </button>

              {/* Answer */}
              <motion.div
                initial={false}
                animate={{
                  height: openIndex === idx ? 'auto' : 0,
                  opacity: openIndex === idx ? 1 : 0,
                }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-6 pb-4 text-slate-400 leading-relaxed border-t border-slate-700/50">
                  {faq.answer}
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <p className="text-slate-400 mb-4">Još pitanja?</p>
          <button className="px-8 py-4 bg-gradient-to-r from-indigo-600 to-pink-600 text-white rounded-lg font-semibold hover:shadow-2xl hover:shadow-indigo-500/50 transition-all duration-300">
            Kontaktiraj nas
          </button>
        </motion.div>
      </div>
    </section>
  );
}
